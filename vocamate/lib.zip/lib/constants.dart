import 'dart:ui';

const Color themecolor_blue = Color.fromRGBO(75, 85, 255, 1.0);
const Color themecolor_pink = Color.fromRGBO(255, 120, 112, 1.0);
const Color themecolor_mint = Color.fromRGBO(63, 253, 225, 1.0);
const Color themecolor_purple = Color.fromRGBO(94, 88, 239, 1.0);
const Color themecolor_green = Color.fromRGBO(74,220,131, 1.0);
