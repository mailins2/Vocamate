import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class LogIn extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }

}